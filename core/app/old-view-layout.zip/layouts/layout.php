<?php
$title = ConfigurationData::getByPreffix("general_main_title")->val;

$cats = CategoryData::getPublicsRoot();
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Katana PRO - Sistema de Tienda en Linea</title>


  <link rel="stylesheet" type="text/css" href="res/lib/font-awesome/css/font-awesome.min.css">

  <script src="res/lib/jquery/jquery.min.js"></script>
  <script src="res/bootstrap-rating.min.js"></script>


  <!-- Bootstrap core CSS -->
  <link href="res/mdbootstrap/css/bootstrap.min.css" rel="stylesheet">



</head>
<body >
<section>
  <div class="container">
    <div class="row">
      <div class="col-md-3 col-xs-5">
      <h1 style="font-size: 40px; margin: 15px 0px ;  "><?php echo $title; ?></h1>
      </div>
      <div class="col-md-7 col-xs-5">
<br>
<form class="form-horizontal" role="form">
<div class="input-group">
<input type="hidden" name="view" value="products">
<input type="hidden" name="act" value="search">
      <input type="text" name="q" placeholder="Buscar productos ..." class="form-control">
      <span class="input-group-btn">
        <button class="btn btn-primary" type="button">&nbsp;<i class="fa fa-search"></i>&nbsp;</button>
      </span>
    </div><!-- /input-group -->
</form>
<br><br>
      </div>
      <div class="col-md-2 col-xs-2">
        <!-- cart button -->
<br>
<a href="index.php?view=mycart" class="btn btn-block btn-secondary"><i class="fa fa-shopping-cart"></i> 
<?php if(isset($_SESSION["cart"])):?>
<span class="badge"><?php echo count($_SESSION["cart"]); ?></span>
<?php endif; ?>
      </a>
      </div>

    </div>
  </div>
</section>


<nav class="navbar navbar-expand-lg navbar-light bg-secondary">
  <div class="container">
<!--  <a class="navbar-brand" href="#">Navbar</a> -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item ">
        <a class="nav-link" href="./">INICIO <span class="sr-only">(current)</span></a>
      </li>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          CATEGORIAS
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
<?php foreach($cats as $cat):?>
          <a class="dropdown-item" href="index.php?view=category&cat=<?php echo $cat->short_name; ?>"><?php echo $cat->name; ?></a>
<?php endforeach; ?>

        </div>
      </li>



    </ul>
    <ul class="navbar-nav ml-auto">

<?php if(!isset($_SESSION["client_id"])):?>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          ACCESO
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="index.php?view=clientaccess">INICIAR SESION</a>
          <a class="dropdown-item" href="index.php?view=register">REGISTRATE</a>

        </div>
      </li>
<?php else:
$client = ClientData::getById($_SESSION["client_id"]);

  ?>
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <?php echo $client->name; ?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="index.php?view=client">MI CUENTA</a>
          <a class="dropdown-item" href="logout.php">SALIR</a>

        </div>
      </li>
<?php endif; ?>

    </ul>

  </div>
</div>
</nav>
<br>
<?php View::load("index"); ?>
<br><br><br>
<section>
<div class="container">

<!-- - - - -->
<div class="row">
<div class="col-md-12">
<hr>
<p><b>Katana PRO</b> v5.3 &copy; 2020</p>
<ul class="list-inline">
<li><p class="text-muted">Powered by <a href="http://evilnapsis.com/" target="_blank">Evilnapsis</a></p></li>
</ul>
</div>
</div>
</div>
</section>
<br>
  <script src="res/mdbootstrap/js/bootstrap.min.js"></script>
  <script>
  $(".tip").tooltip();
  </script>
</body>
</html>