<br><br><br><br>
<div class="container">
	<div class="row">
		<div class="col-md-3"></div>
		<div class="col-md-6">
			<div class="card">
        <div class="card-header">REGISTRO DE CLIENTES</div>
        <div class="card-body">
<form class="form-horizontal" role="form" method="post" action="index.php?action=clientaccess">

  <div class="form-group">
    <label for="inputEmail1" class="control-label">Correo Electronico</label>
    <div class="">
      <input type="email" name="email" class="form-control" id="inputEmail1" placeholder="Correo Electronico">
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword1" class="control-label">Contrase&ntilde;a</label>
    <div class="">
      <input type="password" name="password" class="form-control" id="inputPassword1" placeholder="Contrase&ntilde;a">
    </div>
  </div>
  <div class="form-group">
    <div class="">
      <button type="submit" class="btn btn-block btn-primary">Registrarme</button>
    </div>
  </div>
</form>
				</div>
			</div>
		</div>
	</div>
</div>
<br><br><br>

